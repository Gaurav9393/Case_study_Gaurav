package coupon_system.enums;

public enum ClientType {
    ADMIN,
    COMPANY,
    CUSTOMER
}
