package coupon_system.enums;

public enum CouponType {
    RESTAURANTS,
    ELECTRICITY,
    FOOD,
    HEALTH,
    SPORTS,
    CAMPING,
    TRAVELLING
}
