import {Component} from '@angular/core'

@Component({
  selector: 'app-authorization',
  templateUrl: './authorisation.component.html',
  styleUrls: ['./authorisation.component.css']
})
export class AuthorisationComponent {

  constructor() {
  }

}
