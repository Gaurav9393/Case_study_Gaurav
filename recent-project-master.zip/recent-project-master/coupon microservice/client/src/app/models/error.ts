export class Error {
  constructor(public status: number, public message: string) {
  }
}
