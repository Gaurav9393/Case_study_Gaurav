import {User} from "./user"

export class Customer implements User {
}
