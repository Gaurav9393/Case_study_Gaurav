export interface Income {
  id?: number
  companyName?: String
  customerName?: String
  date?: String
  description?: String
}
