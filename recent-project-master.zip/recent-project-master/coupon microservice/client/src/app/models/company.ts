import {User} from "./user"

export class Company implements User {
}

